// Access DOM Elements
let addNote = document.getElementById("notebtn");
let deleteIcon = document.querySelector(".icon");
let addBtn = document.querySelector(".save-btn");
let notesContainer = document.querySelector(".newNotes");

// Show the Add Note form

addNote.addEventListener("click",function(){
   document.querySelector(".Addform").style.display="block";
});
  // delete the Add Note form

deleteIcon.addEventListener("click",function(){
  document.querySelector(".Addform").style.display="none";
  document.getElementById("title").value = "";
    document.getElementById("description").value = "";
});

// Save the note and display it in the notes section

addBtn.addEventListener("click",function(){
  let titlevalue = document.getElementById("title").value;
  let descriptionValue = document.getElementById("description").value;

})

//check if both boxes are empty

if (titlevalue === "" || descriptionValue === "") {
     alert ("Please fill  both the title and description");
     return;
}
 // create a new Note

 let div = document.createElement("div")
 div.classList.add("myNote");
 div.innerHTML = `
        <h2>${titlevalue}</h2>
        <p>${descriptionvalue}</p>
        <button>Delete</button>
    `;
// Append the new note to the container
notesContainer.appendChild(div);

// Clear the input fields and close the form
document.getElementById("title").value = "";
document.getElementById("description").value = "";
document.querySelector(".Addform").style.display = "none";

// Add delete functionality to the note
div.querySelector("button").addEventListener("click", function() {
    div.remove();
});




